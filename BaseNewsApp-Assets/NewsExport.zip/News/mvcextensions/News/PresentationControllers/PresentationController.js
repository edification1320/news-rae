define([], function() {
    /**
     * User defined presentation controller
     * @constructor
     * @extends kony.mvc.Presentation.BasePresenter
     */
    function PresentationController() {
        kony.mvc.Presentation.BasePresenter.call(this);
    }

    inheritsFrom(PresentationController, kony.mvc.Presentation.BasePresenter);

    /**
     * Overridden Method of kony.mvc.Presentation.BasePresenter
     * This method gets called when presentation controller gets initialized
     * @method
     */
    PresentationController.prototype.initializePresentationController = function() {
        
    };

	/*
     * This function is responsible for invoking the getArticles function 
     * in the business controller of the News Manager
     */
	PresentationController.prototype.getArticles = function (type) {
		kony.print ("Entering into NewsModule.PresentationController.getArticles");
      
        //Get reference for NewsModule's business controller and invoke getArticles function in it
        var newsManager = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("NewsManager");
        var newsManagerBusinessController = newsManager.businessController;
        kony.print ("Invoking getArticles in the business controller of News manager");
        newsManagerBusinessController.getArticles(type, this.getArticlesSuccessCallback, this.getArticlesErrorCallback);
      
		kony.print ("Exiting out of NewsModule.PresentationController.getArticles");
	};
  
	/*
     * This function is responsible for hadling the success response
     * from getAtcicles service call on the articles object in DigitalObjects object service
     */
	PresentationController.prototype.getArticlesSuccessCallback = function (response) {
      kony.print ("Entering into NewsModule.PresentationController.getArticlesSuccessCallback");
      var navigationObject = new kony.mvc.Navigation("frmArticles");
      navigationObject.navigate({"getArticlesSuccessResponse":response});
      kony.print ("Exiting out of NewsModule.PresentationController.getArticlesSuccessCallback");
    };
  
	/*
     * This function is responsible for hadling the error response
     * from getAtcicles service call on the articles object in DigitalObjects object service
     */
	PresentationController.prototype.getArticlesErrorCallback = function (response) { 
      kony.print ("Entering into NewsModule.PresentationController.getArticlesErrorCallback");
      var navigationObject = new kony.mvc.Navigation("frmArticles");
      navigationObject.navigate({"getArticlesErrorResponse":response});
      kony.print ("Exiting out of NewsModule.PresentationController.getArticlesErrorCallback");
    };
  
    return PresentationController;
});