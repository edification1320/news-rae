/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define([], function(){
	var repoMapping = {
		article  : {
			model : "DigitalObjects/article/Model",
			config : "DigitalObjects/article/MF_Config",
			repository : "DigitalObjects/article/Repository",
		},
	};

	return repoMapping;
})