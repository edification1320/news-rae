define([], function(){
	var BaseRepository = kony.mvc.Data.BaseRepository;

	//Create the Repository Class
	function articleRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
		BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
	};

	//Setting BaseRepository as Parent to this Repository
	articleRepository.prototype = Object.create(BaseRepository.prototype);
	articleRepository.prototype.constructor = articleRepository;

	//For Operation 'getArticles' with service id 'digitaldb_article_get3457'
	articleRepository.prototype.getArticles = function(params, onCompletion){
		return articleRepository.prototype.customVerb('getArticles', params, onCompletion);
	};

	return articleRepository;
})