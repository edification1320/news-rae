define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** init defined for frmArticles **/
    AS_Form_d70f076ad2d74f119adce38f70b4efd0: function AS_Form_d70f076ad2d74f119adce38f70b4efd0(eventobject) {
        var self = this;
        return self.initCallback.call(this);
    }
});