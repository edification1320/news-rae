CREATE DATABASE  IF NOT EXISTS `digitaldb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `digitaldb`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: digitaldb
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `headline` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `publisheddate` varchar(45) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `publishedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `type_idx` (`type`),
  CONSTRAINT `type` FOREIGN KEY (`type`) REFERENCES `type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'Thirimanne and Oshada Fernando leads Sri Lanka’s fight back, takes 153 runs lead','WI vs SL 1st Test Day 3 LIVE Score – Trailing by 102 runs to West Indies in the 1st innings, Sri Lanka fought back on the 3rd day led by brilliant batting from Lahiru Thirimanne & Oshada Fernando. At the end of Day 3 Sri Lanka has stretched their lead to 153 runs with a score of 255/4. ','March 24, 2021',2,'InsideSport Desk'),(2,'MS Dhoni’s masterstroke, ‘making CSK players simulate match situations’','IPL 2021 – CSK MS Dhoni Training Camp: Chennai Super Kings are going all guns at their training camp for the upcoming Indian Premier League (IPL) 2021 season. CSK skipper MS Dhoni, who is probably playing his last edition, is doing everything to overcome the ghosts from last year and get his hands on the shiny IPL trophy for the fourth time','March 24, 2021',2,'InsideSport Desk'),(3,'Mumbai Indians surprise package for IPL 2021, signs 6ft8inch pacer Marco Jansen','IPL 2021: Mumbai Indians New Signing: Rohit Sharma’s Mumbai Indians has surprised everyone with their new signing. The defending champions have signed 6 feet 8 Inches South Africa’s upcoming pacer Marco Jansen. His claim to fame – he at the nets in 2018 kept beating India’s captain Virat Kohli with his pace.','March 24, 2021',2,'InsideSport Desk'),(4,'Star Sports launch new and modern anthem for IPL 14; Watch video','IPL 2021 Anthem: Star Sports, official broadcasters of Indian Premier League (IPL) 2021, on Tuesday, released the new anthem for this season. The network took to Twitter to announce, the new IPL anthem titled “India ka Apna Mantra”. ','March 24, 2021',2,'InsideSport Desk'),(5,'FIFA Revenues: FIFA gaming revenues in 2020 more than the football revenues','FIFA Revenues – FIFA E-Gaming Shines: This piece of news will surprise sports marketing companies, sports federations and the entire sports business fraternity. In accordance with the growing trend world over, FIFA E-Gaming Revenues outstripped FIFA’s traditional football revenues in Year 2020.','March 24, 2021',2,'InsideSport Desk'),(6,'Sports Business: Bundesliga clubs face 5.4 pct total revenue loss due to COVID-19','Sports Business – Bundesliga clubs total revenue 2019-20: The German League top tier and second-flight clubs have seen a drop in 2019-20 total revenue due to the COVID-19 pandemic. One of the major reasons for the drop of 5.4 per cent and 7.2 respectively is caused by the decline in ticket and transfer income.','March 24, 2021',2,'InsideSport Desk'),(7,'Miami Open: Novak Djokovic withdraws from Miami Open, citing COVID restrictions','The Serbian tennis star cited coronavirus restrictions while announcing that he will miss the upcoming tournament. Djokovic has now joined Spanish tennis players Rafael Nadal and Roger Federer in the list of players who have withdrawn from the Miami Open.','March 24, 2021',2,'InsideSport Desk');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-15 15:10:59
