define([], function () { 
    
    /**
     * User defined business controller
     * @constructor
     * @extends kony.mvc.Business.Delegator
     */
    function BusinessController() { 

        kony.mvc.Business.Delegator.call(this); 

    } 

    inheritsFrom(BusinessController, kony.mvc.Business.Delegator); 

	/*
     * This function is responsible for invoking the getArticles custom verb
     * on the article object in 
     */
	BusinessController.prototype.getArticles = function (type, successCallback, errorCallback) {
		kony.print ("Entering into NewsManager.BusinessController.getArticles");
      
        //Get reference for article object in DigitalObject object service
        var articleObject = kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("article");
        articleObject.customVerb("getArticles", {"type":type}, completionCallback);
      
		kony.print ("Exiting out of NewsManager.BusinessController.getArticles");
      
		function completionCallback (status, response) {
			kony.print ("Entering into NewsManager.BusinessController.getArticles.completionCallback");
			kony.print ("Response receive into NewsManager.BusinessController.getArticles: "+JSON.stringify(response));
			if (100 === status && null !== response && undefined !== response) {
				successCallback(response);
            } else {
				errorCallback(response);
            } 
			kony.print ("Exiting out of NewsManager.BusinessController.getArticles.completionCallback");
        }
	};
  
    return BusinessController;

});