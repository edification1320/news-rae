/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define([], function() {
	var mappings = {
		"description": "description",
		"headline": "headline",
		"id": "id",
		"publishedby": "publishedby",
		"publisheddate": "publisheddate",
		"type": "type",
	};

	Object.freeze(mappings);

	var typings = {
		"description": "string",
		"headline": "string",
		"id": "number",
		"publishedby": "string",
		"publisheddate": "string",
		"type": "number",
	}

	Object.freeze(typings);

	var primaryKeys = [
					"id",
	];

	Object.freeze(primaryKeys);

	var config = {
		mappings: mappings,
		typings: typings,
		primaryKeys: primaryKeys,
		serviceName: "DigitalObjects",
		tableName: "article"
	};

	Object.freeze(config);

	return config;
})