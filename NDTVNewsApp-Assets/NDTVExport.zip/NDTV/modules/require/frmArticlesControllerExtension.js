define(function () {

  return {

    types : {
      "WORLD" : "ndtvnews-world-news",
      "SPORTS" : "ndtvsports-latest",
      "ENTERTAINMENT" : "ndtvmovies-latest",
      "HEALTH" : "ndtvcooks-latest",
      "POLITICS" : "ndtvnews-trending-news",
      "LATEST" : "ndtvnews-latest",
      "TRAVEL" : "ndtvnews-cities-news",
      "TECH" : "gadgets360-latest",
    }

  };
});