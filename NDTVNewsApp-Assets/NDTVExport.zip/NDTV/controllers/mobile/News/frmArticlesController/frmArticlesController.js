define({ 

  types : {
    "WORLD" : "1",
    "SPORTS" : "2",
    "ENTERTAINMENT" : "3",
    "HEALTH" : "4",
    "POLITICS" : "5",
    "LATEST" : "6",
    "TRAVEL" : "7",
    "LIFESTYLE" : "8",
    "SCIENCE" : "9",
    "TECH" : "10",
  },
  
  onNavigate : function (params) {
    kony.print ("Entering into frmArticlesController.onNavigate");
    if (null !== params && undefined !== params) {
      if (null !== params.getArticlesSuccessResponse && undefined !==  params.getArticlesSuccessResponse && 0 !==  params.getArticlesSuccessResponse.length) {
        this.view.segArticles.widgetDataMap = 	{
													"rtxArticleTitle":"headline",
													"lblArticlePublishedDate":"publisheddate",
													"lblArticlePublishedBy":"publishedby",
													"rtxArticleDetails":"description",
												};
        this.view.segArticles.setData(params.getArticlesSuccessResponse);
      } 
    }
    kony.print ("Exiting out of frmArticlesController.onNavigate");
  },
  
  /*
   * This function is responsible to
   * perform actions in the init event of this form
   * 
   * Actions being handled in this function are
   * - assigning the function to be invoked in the postShow event of the form
   * - assigning the actions for each newType button click
   * - invoking restSkinsForNewsTypeButtons
   */
  initCallback : function () {
    kony.print ("Entering into frmArticlesController.initCallback");
    
    //Assigning the actions for each newType button click
    this.view.btnLatest.onClick = this.btnLatestOnClickHandler;
    this.view.btnWorld.onClick = this.btnWorldOnClickHandler;
    this.view.btnSports.onClick = this.btnSportsOnClickHandler;
    this.view.btnScience.onClick = this.btnScienceOnClickHandler;
    this.view.btnTech.onClick = this.btnTechOnClickHandler;
    this.view.btnHealth.onClick = this.btnHealthOnClickHandler;
    this.view.btnTravel.onClick = this.btnTravelOnClickHandler;
    
    this.restSkinsForNewsTypeButtons();
    
    //Invoke getArticles function with newType as latest
    this.getArticles(this.types.LATEST);

    kony.print ("Exiting out of frmArticlesController.initCallback");
  },
  
  
  /*
   * This function is responsible to
   * perform actions in the postShow event of btnLatest
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "LATEST"
   */
  btnLatestOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnLatestOnClickHandler");
    this.getArticles(this.types.LATEST);
    kony.print ("Exiting out of frmArticlesController.btnLatestOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the postShow event of btnWorld
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "WORLD"
   */
  btnWorldOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnWorldOnClickHandler");
    this.getArticles(this.types.WORLD);
    kony.print ("Exiting out of frmArticlesController.btnWorldOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the postShow event of btnSports
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "SPORTS"
   */
  btnSportsOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnSportsOnClickHandler");
    this.getArticles(this.types.SPORTS);
    kony.print ("Exiting out of frmArticlesController.btnSportsOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the postShow event btnScience
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "SCIENCE"
   */
  btnScienceOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnScienceOnClickHandler");
    this.getArticles(this.types.SCIENCE);
    kony.print ("Exiting out of frmArticlesController.btnScienceOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the postShow event of btnTech
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "TECH"
   */
  btnTechOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnTechOnClickHandler");
    this.getArticles(this.types.TECH);
    kony.print ("Exiting out of frmArticlesController.btnTechOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the postShow event of btnHealth
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "HEALTH"
   */
  btnHealthOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnHealthOnClickHandler");
    this.getArticles(this.types.HEALTH);
    kony.print ("Exiting out of frmArticlesController.btnHealthOnClickHandler");
  },

  /*
   * This function is responsible to
   * perform actions in the onClick event of tnTravel
   * 
   * Actions being handled in this function are
   * - invoking the getArticles function with newType as "TRAVEL"
   */
  btnTravelOnClickHandler : function () {
    kony.print ("Entering into frmArticlesController.btnTravelOnClickHandler");
	this.getArticles(this.types.TRAVEL);
    kony.print ("Exiting out of frmArticlesController.btnTravelOnClickHandler");
  },
  
  /*
   * This function is responsible to
   * perform actions in the postShow event of this form
   */
  postShowCallback : function () {
    kony.print ("Entering into frmArticlesController.postShowCallback");
    kony.print ("Exiting out of frmArticlesController.postShowCallback");
  },
  
  /*
   * This function is responsible for invoking the getArticles function in
   * presentation controller of News module
   */
  getArticles : function (type) {
    kony.print ("Entering into frmArticlesController.getArticles");
    
    //Check that the new type is valid and proceed to fetch articles
    if (null !== type && undefined !== type && "" !== type) {
      //Get reference for NewsModule's presentation controller and invoke getArticles function in it
      var newsModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("News");
      var newModulePresentationController = newsModule.presentationController;
      kony.print ("Invoking getArticles in the presentation controller of News module");
      newModulePresentationController.getArticles(type);
    } else {
      alert ("Please select a proper newType to fetch the new articles");
    }
    
    kony.print ("Exiting out of frmArticlesController.getArticles");
  },
  
  /*
   * This function is responsible to
   * setting the default values for skin and focusSkin 
   * properties of newType buttons in this form
   */
  restSkinsForNewsTypeButtons : function () {
    kony.print ("Entering into frmArticlesController.restSkinsForNewsTypeButtons");

    this.view.btnLatest.skin = sknBtn2;
    this.view.btnWorld.skin = sknBtn1;
    this.view.btnSports.skin = sknBtn1;
    this.view.btnScience.skin = sknBtn1;
    this.view.btnTech.skin = sknBtn1;
    this.view.btnHealth.skin = sknBtn1;
    this.view.btnTravel.skin = sknBtn1;

    this.view.btnLatest.focusSkin = sknBtn2;
    this.view.btnWorld.focusSkin = sknBtn2;
    this.view.btnSports.focusSkin = sknBtn2;
    this.view.btnScience.focusSkin = sknBtn2;
    this.view.btnTech.focusSkin = sknBtn2;
    this.view.btnHealth.focusSkin = sknBtn2;
    this.view.btnTravel.focusSkin = sknBtn2;
    
    kony.print ("Exiting out of frmArticlesController.restSkinsForNewsTypeButtons");
  }

 });